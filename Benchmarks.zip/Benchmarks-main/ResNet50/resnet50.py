#!/usr/bin/env python3

# Original code: https://pytorch.org/hub/nvidia_deeplearningexamples_resnet50/

import argparse
from datetime import datetime
import os
from pathlib import Path
import time
import torch
import warnings

warnings.filterwarnings("ignore")

device = torch.device("cpu")
print(f"Using {device} for inference")

resnet50 = torch.hub.load(
    "NVIDIA/DeepLearningExamples:torchhub", "nvidia_resnet50", pretrained=True
)
utils = torch.hub.load(
    "NVIDIA/DeepLearningExamples:torchhub", "nvidia_convnets_processing_utils"
)


def run_resnet(input_directory: Path):
    image_paths = [
        os.path.join(input_directory, file) for file in os.listdir(input_directory)
    ]

    batch = torch.cat([utils.prepare_input_from_uri(img) for img in image_paths]).to(
        device
    )
    with torch.no_grad():
        output = torch.nn.functional.softmax(resnet50(batch), dim=1)

    results = utils.pick_n_best(predictions=output, n=5)

    return zip(image_paths, results)


def directory_exists(directory: str) -> Path:
    path = Path(directory)

    if not path.is_dir():
        raise argparse.ArgumentTypeError(f"directory '{directory}' does not exist.")

    return path


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmarking via ResNet50")

    parser.add_argument(
        "-i",
        "--input-directory",
        type=directory_exists,
        required=True,
        help="The directory with images to process",
    )

    parser.add_argument(
        "-t",
        "--thread-count",
        type=int,
        required=True,
        help="How many threads ResNet50 should run on",
    )

    args = parser.parse_args()

    resnet50.eval().to(device)

    start_datetime = datetime.now()

    print(f"{start_datetime.isoformat()}: Starting {args.thread_count} thread(s)...")

    # https://pytorch.org/docs/stable/notes/cpu_threading_torchscript_inference.html
    torch.set_num_threads(args.thread_count)

    start = time.time()

    run_resnet(args.input_directory)

    end = time.time()

    elapsed = round(end - start, 3)

    print(f"Took {elapsed}s")


if __name__ == "__main__":
    main()
