# Run ResNet50

`./run-all.sh ~/Downloads/images/`

# Killing all spawned threads

If you decide that you don't want the program to continue any longer, run the following:

```
pkill -f -9 "python.*resnet50.py"
```

# Errors

If you get the error below, remove `~/.spack/linux/compilers.yml`, then re-run `./run-all.sh`. See [this issue](https://github.com/spack/spack/issues/3146) for more information.

```
==> Error: InstallError: OpenMPI requires both C and Fortran compilers!

/home/someuser/spack/var/spack/repos/builtin/packages/openmpi/package.py:901, in die_without_fortran:
        898        # dependencies depends_on('mpi'), require Fortran compiler to
        899        # avoid delayed build errors in dependents.
        900        if (self.compiler.f77 is None) and (self.compiler.fc is None):
  >>    901            raise InstallError("OpenMPI requires both C and Fortran compilers!")
```
