#!/usr/bin/env python3

import argparse
from dataclasses import dataclass
import os
from pathlib import Path

from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

INSTANCES = [1, 2, 4, 8, 16]
THREAD_RANGES = [(4, 256), (4, 128), (4, 64), (4, 32), (4, 16)]


@dataclass
class ThreadedInstance:
    image_count: int
    duration: float
    ips: float


def parse_log_file(log_file_path: Path) -> dict | None:
    try:
        with open(log_file_path, mode="r") as f:
            lines = [x.strip() for x in f.readlines() if len(x.strip()) > 0]
            index = 0
            for i, line in enumerate(lines):
                if "sample 0" in line:
                    index = i

            lines = lines[index:]

    except FileNotFoundError:
        return None

    try:
        images, seconds = len(lines[:-1]), float(lines[-1].split()[1][:-1])
        ips = images / seconds

        return {
            "image_count": images,
            "duration": seconds,
            "ips": ips,
        }
    except IndexError:
        print(f"{log_file_path} could not be graphed")
        return None


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create graphs from previously generated CSV files"
    )

    parser.add_argument(
        "-i",
        "--input-dir",
        type=Path,
        required=True,
        help="Where all the data is located",
    )

    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        required=True,
        help="Directory to dump all the graphs into",
    )

    parser.add_argument(
        "-t",
        "--title",
        type=str,
        required=False,
        help="The main title of the graph",
    )

    args = parser.parse_args()

    input_directory: Path = args.input_dir / Path("instances")
    output_directory: Path = args.output_dir

    if not os.path.isdir(output_directory):
        os.makedirs(output_directory)

    combined_data = []

    for (min_thread, max_thread), instance_count in zip(THREAD_RANGES, INSTANCES):
        instance_directory = input_directory / Path(str(instance_count))
        threads = [
            2**i for i in range(min_thread // 2, max_thread) if 2**i <= max_thread
        ]

        for thread_count in threads:
            for i in range(1, instance_count + 1):
                log_file_path = (
                    instance_directory
                    / Path(str(thread_count))
                    / Path(str(i))
                    / Path("logs.txt")
                )
                data = parse_log_file(log_file_path)
                if data is None:
                    continue
                data["thread_count"] = thread_count
                data["instances"] = instance_count
                data["instance_number"] = i
                combined_data.append(data)

    df = pd.DataFrame(combined_data)
    df = df.iloc[:, 2:]
    df["sum_ips"] = df.groupby(["instances", "thread_count"])["ips"].transform("sum")
    df = (
        df.drop(columns=["ips"])
        .reset_index(drop=True)
        .drop(columns=["instance_number"])
        .drop_duplicates()
    )

    df["thread_count"], df["instances"] = df["instances"], df["thread_count"]
    df = df.rename(columns={"thread_count": "instances", "instances": "thread_count"})

    n = len(INSTANCES)

    pivot_df = df.pivot(index="thread_count", columns="instances", values="sum_ips")

    bar_width = 0.15
    index = np.arange(len(pivot_df.index))

    plt.figure(figsize=(10, 10))

    plt.cm.viridis(np.linspace(0, 1, n + 1))

    bars = []
    for i, i_num in enumerate(INSTANCES):
        try:
            bars.append(
                plt.bar(
                    index + i * bar_width,
                    pivot_df[i_num],
                    bar_width,
                    label=f"{i_num} instance{'' if i_num == 0 else 's'}",
                )
            )
        except KeyError:
            pass

    plt.xlabel("Thread Count")
    plt.ylabel("Sum IPS")

    group_positions = index + (n / 2) * bar_width
    group_labels = pivot_df.index

    plt.xticks(group_positions, group_labels)

    if title := args.title:
        plt.title(title)
    else:
        plt.title("Grouped Bar Chart: Thread Count vs. Sum IPS (Images Per Second)")

    def autolabel(bars):
        for bar in bars:
            for rect in bar:
                try:
                    height = int(rect.get_height())
                except ValueError:
                    continue

                plt.annotate(
                    "{}".format(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 10),
                    textcoords="offset points",
                    ha="center",
                    va="bottom",
                    fontsize="xx-small",
                )

    autolabel(bars)

    box = plt.gca().get_position()
    plt.gca().set_position(
        [box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9]
    )
    plt.legend(
        loc="upper center",
        bbox_to_anchor=(0.5, -0.125),
        fancybox=True,
        shadow=True,
        ncol=5,
        fontsize=10,
    )

    f = output_directory / Path("plot.png")
    plt.savefig(f)
    plt.clf()


if __name__ == "__main__":
    main()
