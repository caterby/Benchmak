#!/usr/bin/env python3

import argparse
from dataclasses import dataclass
import os
from pathlib import Path

import pandas as pd

INSTANCES = [1, 2, 4, 8]
THREAD_RANGES = [(4, 128), (4, 64), (4, 32), (4, 16)]


@dataclass
class ThreadedInstance:
    image_count: int
    duration: float
    ips: float


def parse_log_file(log_file_path: Path) -> dict | None:
    try:
        with open(log_file_path, mode="r") as f:
            lines = [x.strip() for x in f.readlines() if len(x.strip()) > 0][4:]
    except FileNotFoundError:
        return None

    images, seconds = len(lines[:-1]), float(lines[-1].split()[1][:-1])
    ips = images / seconds

    return {
        "image_count": images,
        "duration": seconds,
        "ips": ips,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create graphs from previously generated CSV files"
    )

    parser.add_argument(
        "-i",
        "--input-dir",
        type=Path,
        required=True,
        help="Where all the data is located",
    )

    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        required=True,
        help="Directory to dump all the graphs into",
    )

    parser.add_argument(
        "-t",
        "--title",
        type=str,
        required=False,
        help="The main title of the graph",
    )

    args = parser.parse_args()

    input_directory: Path = args.input_dir / Path("instances")
    output_directory: Path = args.output_dir

    if not os.path.isdir(output_directory):
        os.makedirs(output_directory)

    combined_data = []

    for (min_thread, max_thread), instance_count in zip(THREAD_RANGES, INSTANCES):
        instance_directory = input_directory / Path(str(instance_count))
        threads = [
            2**i for i in range(min_thread // 2, max_thread) if 2**i <= max_thread
        ]

        for thread_count in threads:
            for i in range(1, instance_count + 1):
                log_file_path = (
                    instance_directory
                    / Path(str(thread_count))
                    / Path(str(i))
                    / Path("logs.txt")
                )
                data = parse_log_file(log_file_path)
                if data is None:
                    continue
                data["thread_count"] = thread_count
                data["instances"] = instance_count
                data["instance_number"] = i
                combined_data.append(data)

    df = (
        pd.DataFrame(combined_data)
        .iloc[:, 2:]
        .groupby(["instances", "thread_count"])
        .sum()
        .drop(columns=["instance_number"])
    )

    print(df)


if __name__ == "__main__":
    main()
