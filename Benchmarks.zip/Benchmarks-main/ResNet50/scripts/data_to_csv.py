#!/usr/bin/env python3

import argparse
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

INSTANCES = [1, 2, 4, 8, 16]
THREAD_RANGES = [(4, 256), (4, 128), (4, 64), (4, 32), (4, 16)]


@dataclass
class ThreadedInstance:
    image_count: int
    duration: float
    ips: float


def parse_log_file(log_file_path: Path) -> dict | None:
    try:
        with open(log_file_path, mode="r") as f:
            lines = [x.strip() for x in f.readlines() if len(x.strip()) > 0]
            index = 0
            for i, line in enumerate(lines):
                if "sample 0" in line:
                    index = i

            lines = lines[index:]

    except FileNotFoundError:
        return None

    try:
        images, seconds = len(lines[:-1]), float(lines[-1].split()[1][:-1])
        ips = images / seconds

        return {
            "image_count": images,
            "duration": seconds,
            "ips": ips,
        }
    except IndexError:
        print(f"{log_file_path} could not be graphed")
        return None


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create graphs from previously generated CSV files"
    )

    parser.add_argument(
        "-i",
        "--input-dir",
        type=Path,
        required=True,
        help="Where all the data is located",
    )

    parser.add_argument(
        "-o",
        "--output-file",
        type=Path,
        default=Path("results.csv"),
        help="Where to put the CSV file",
    )

    args = parser.parse_args()

    input_directory: Path = args.input_dir / Path("instances")
    output_file: Path = args.output_file

    combined_data = []

    for (min_thread, max_thread), instance_count in zip(THREAD_RANGES, INSTANCES):
        instance_directory = input_directory / Path(str(instance_count))
        threads = [
            2**i for i in range(min_thread // 2, max_thread) if 2**i <= max_thread
        ]

        for thread_count in threads:
            for i in range(1, instance_count + 1):
                log_file_path = (
                    instance_directory
                    / Path(str(thread_count))
                    / Path(str(i))
                    / Path("logs.txt")
                )
                data = parse_log_file(log_file_path)
                if data is None:
                    continue
                data["thread_count"] = thread_count
                data["instances"] = instance_count
                data["instance_number"] = i
                combined_data.append(data)

    df = pd.DataFrame(combined_data)
    df = df.iloc[:, 2:]
    df["sum_ips"] = df.groupby(["instances", "thread_count"])["ips"].transform("sum")
    df = (
        df.drop(columns=["ips"])
        .reset_index(drop=True)
        .drop(columns=["instance_number"])
        .drop_duplicates()
    )

    df["thread_count"], df["instances"] = df["instances"], df["thread_count"]
    df = df.rename(columns={"thread_count": "instances", "instances": "thread_count"})

    df.to_csv(output_file, index=False)


if __name__ == "__main__":
    main()
