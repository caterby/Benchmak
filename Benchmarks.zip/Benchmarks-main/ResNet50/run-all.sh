#!/usr/bin/env bash

if [ $# -eq 0 ]; then
    echo "Error: Input directory path argument is missing."
    echo "Usage: $0 <input-directory>"
    exit 1
fi

directory_path="$1"

if [ ! -d "$directory_path" ]; then
    echo "Error: Directory '$directory_path' does not exist."
    exit 2
fi

function check_and_install_spack()
{
    echo "Running check and install of spack"

    if [ -z ${SPACK_ROOT} ];
    then
        if [ ! -d ~/spack ];
        then
            echo "Installing Spack in the home directory"
            cd ~
            git clone https://github.com/spack/spack.git
        fi
        source ~/spack/share/spack/setup-env.sh
    fi
}

function check_and_install_tools()
{
    echo "Running check and installation of tools"

    check_and_install_spack

    local install="1"

    if command -v gcc > /dev/null 2>&1; then
        install="0"
    fi

    if command -v gfrotran > /dev/null 2>&1; then
        install="0"
    fi

    if [ "${install}" -eq "1" ];
    then
        if command -v apt &> /dev/null; then
            sudo apt update
            sudo apt -y install build-essential gfortran
        elif command -v dnf &> /dev/null; then
            sudo dnf check-update
            sudo dnf -y groupinstall "Development Tools"
            sudo dnf -y install gfortran
        elif command -v yum &> /dev/null; then
            sudo yum check-update
            sudo yum -y groupinstall "Development Tools"
            sudo yum -y install gfortran
        else
            echo "[ERROR] Package manager not found. Cannot install tools."
            exit 1
        fi
    fi
}

function check_and_install_python_spack_dependencies()
{
    echo "Running check and install of Python spack dependencies"

    packages=("py-torch" "py-torchvision" "py-validators")

    for package in "${packages[@]}"
    do
        local output=$( spack find | grep -w $package )

        if [ -z ${output} ];
        then
            echo "Installing spack package $package"
            spack install $package
        fi

        spack load $package
    done
}

function run_resnet50_threaded_instances()
{
    echo "Running resnet50 threaded instances"

    sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"

    threads=(4 8 16 32 64 128)
    indices=(1 2 3 4)

    for i in "${indices[@]}"; do
        threads_slice_length=$(( ${#threads[@]} - i + 1 ))
        threads_slice=("${threads[@]:0:threads_slice_length}")

        for thread_count in "${threads_slice[@]}"; do
            instance_count=$((1 << (i - 1)))

            echo "Spawning $instance_count instances of resnet50, $thread_count thread(s) each."

            for j in $(seq 1 $instance_count); do
                mkdir -p ./output/instances/$instance_count/$thread_count/$j/
            done

            pids=()

            for j in $(seq 1 $instance_count); do
                log_file_path=./output/instances/$instance_count/$thread_count/$j/logs.txt
                numactl --cpunodebind=1 --membind=2 ./resnet50.py -i $directory_path -t $thread_count > $log_file_path 2>&1 &
                pids[$j]=$!
                echo "${pids[$j]}"
            done

            all_succeeded=true
            for pid in ${pids[*]}; do
                wait ${pid}
                if [ "$?" -ne "0" ];
                then
                    echo "[FATAL]: Process / Instance failed with exit code $?"
                    all_succeeded=false
                fi
            done

            unset pids

            if ! $all_succeeded; then
                echo $all_succeeded
                echo "Instances of count $instance_count killed or stopped, removing logs"
                rm -rf ./output/instances/$instance_count/
                break 2
            fi
        done
    done
}

check_and_install_tools
check_and_install_python_spack_dependencies
run_resnet50_threaded_instances
exit
