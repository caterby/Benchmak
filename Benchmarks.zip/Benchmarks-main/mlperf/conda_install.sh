#!/bin/bash

if command -v conda &>/dev/null; then
    echo "[INFO] conda is installed on your system"
    exit 0
fi

if command -v apt > /dev/null 2>&1;
then
    # Install conda public GPG key to trusted store
    curl https://repo.anaconda.com/pkgs/misc/gpgkeys/anaconda.asc | gpg --dearmor > conda.gpg
    install -o root -g root -m 644 conda.gpg /usr/share/keyrings/conda-archive-keyring.gpg

    # Check whether fingerprint is correct (will output an error message otherwise)
    gpg --keyring /usr/share/keyrings/conda-archive-keyring.gpg --no-default-keyring --fingerprint 34161F5BF5EB1D4BFBBB8F0A8AEB4F8B29D82806
    # Add conda Debian repo
    echo "deb [arch=amd64 signed-by=/usr/share/keyrings/conda-archive-keyring.gpg] https://repo.anaconda.com/pkgs/misc/debrepo/conda stable main" | sudo tee -a /etc/apt/sources.list.d/conda.list

    # Install using apt
    if command -v apt >/dev/null 2>&1; then
        sudo apt update
    else
        echo "[ERROR] Package manager: apt not found. Cannot install"
        exit 1
    fi

    # Install conda
    sudo apt install conda
    # activate conda
    source /opt/conda/etc/profile.d/conda.sh

elif command -v dnf > /dev/null 2>&1;
then
    sudo dnf install conda -y
fi
