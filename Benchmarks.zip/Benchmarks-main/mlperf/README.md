## Automation Script
### Vision Inference
This test will run 10 minutes: \
Model: mobile-net \
Data: fake ImageNet style
```shell
sudo ./mlperf_vision_run.sh
```
### LLM Inference
This test will run 50 minutes: \
Model: gpt-j \
Data: cnndm
```shell
./mlperf_llm_run.sh -s <number of samples>
```

