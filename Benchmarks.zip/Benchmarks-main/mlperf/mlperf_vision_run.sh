#!/bin/bash
model_dir=mobile_net

# Clone the repo
if [ -d "./inference" ]; then
    echo "The ./inference directory already exists. Skipping clone operation."
else
    # If the directory does not exist, clone the repository
    git clone https://github.com/mlcommons/inference.git
fi
cd ./inference/vision/classification_and_detection
# Generate fake imagenet
echo "Generating fake imagenet images..."
cd ./tools
./make_fake_imagenet.sh
cd ..
# Download pretrained mobilenet
echo "Downloading pretrained mobilenet model..."
if [ -d "$model_dir" ]; then
    echo "Directory $model_dir already exist."
else
    mkdir "$model_dir"
fi
cd "$model_dir"
if [ -f "mobilenet_v1_1.0_224.onnx" ]; then
    echo "Model mobilenet_v1_1.0_224.onnx already exist. Skip downloading."
else
    wget -q https://zenodo.org/record/3157894/files/mobilenet_v1_1.0_224.onnx
fi
cd ..
# Set the environment variable
current_path=$(pwd)
model_path="${current_path}/${model_dir}"
echo "Model Path: $model_path"
data_path="${current_path}/tools/fake_imagenet"
echo "Data Path: $data_path"
export MODEL_DIR="$model_path"
export DATA_DIR="$data_path"
# Run the test
./run_and_time.sh onnxruntime mobilenet cpu
