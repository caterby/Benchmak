#!/bin/bash
WORK_DIR=$PWD

function set_conda_environment()
{
    __conda_setup="$('/usr/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
    if [ $? -eq 0 ]; then
        eval "$__conda_setup"
    else
        if [ -f "/usr/etc/profile.d/conda.sh" ]; then
            . "/usr/etc/profile.d/conda.sh"
        else
            export PATH="/usr/bin:$PATH"
        fi
    fi
    unset __conda_setup

    # Set up environment
    if conda env list | grep ^llm > /dev/null 2>&1 ;
    then
        echo "[INFO]: llm environment exists"
    else
        #conda create -n llm python=3.9 -y
        conda create -n llm python=3.10 -y
    fi
    conda activate llm
}

function unset_conda_environment()
{
    conda deactivate
}


function install_conda_packages()
{
    # Create Environment (conda)
    if conda list mkl | grep -w "^mkl " > /dev/null 2>&1;
    then
        echo "[INFO]: mkl package is installed"
    else
        conda install mkl -y
    fi

    if conda list mkl-include | grep -w "^mkl-include" > /dev/null 2>&1;
    then
        echo "[INFO]: mkl-include package is installed"
    else
        conda install mkl-include -y
    fi

    if conda list gperftools | grep -w "^gperftools" > /dev/null 2>&1;
    then
        echo "[INFO]: gperftools-include package is installed"
    else
        conda install gperftools -c conda-forge -y
    fi

    if conda list jemalloc | grep -w "^jemalloc" > /dev/null 2>&1;
    then
        echo "[INFO]: jemalloc-include package is installed"
    else
        conda install jemalloc==5.2.1 -c conda-forge -y
    fi
}

function install_pip_packages()
{
    # install pytorch
    # you can find other nightly version in https://download.pytorch.org/whl/nightly/
    if pip show torch | grep "^Name: torch$" > /dev/null 2>&1;
    then
    echo "[INFO] pip PyTorch package is installed"
    else
        pip install https://download.pytorch.org/whl/nightly/cpu-cxx11-abi/torch-2.0.0.dev20230228%2Bcpu.cxx11.abi-cp39-cp39-linux_x86_64.whl
    fi


    # installation
    if pip show pyyaml | grep "^Name: pyyaml$" > /dev/null 2>&1;
    then
    echo "[INFO] pip pyyaml package is installed"
    else
        pip install pyyaml
    fi
    if pip show requests | grep "^Name: requests$" > /dev/null 2>&1;
    then
    echo "[INFO] pip requests package is installed"
    else
        pip install requests
    fi
    if pip show transformers | grep "^Name: transformers$" > /dev/null 2>&1;
    then
    echo "[INFO] pip transformers package is installed"
    else
        pip install transformers
    fi
    if pip show datasets | grep "^Name: datasets$" > /dev/null 2>&1;
    then
    echo "[INFO] pip datasets package is installed"
    else
        pip install datasets
    fi
    if pip show evaluate | grep "^Name: evaluate$" > /dev/null 2>&1;
    then
    echo "[INFO] pip evaluate package is installed"
    else
        pip install evaluate
    fi
    if pip show accelerate | grep "^Name: accelerate$" > /dev/null 2>&1;
    then
    echo "[INFO] pip accelerate package is installed"
    else
        pip install accelerate
    fi
    if pip show simplejson | grep "^Name: simplejson$" > /dev/null 2>&1;
    then
    echo "[INFO] pip simplejson package is installed"
    else
        pip install simplejson
    fi
    if pip show nltk | grep "^Name: nltk$" > /dev/null 2>&1;
    then
    echo "[INFO] pip nltk package is installed"
    else
        pip install nltk
    fi
    if pip show rouge_score | grep "^Name: rouge_score$" > /dev/null 2>&1;
    then
    echo "[INFO] pip rouge_score package is installed"
    else
        pip install rouge_score
    fi
}

function set_environment_variables()
{
    # Setup Environment Variables
    export KMP_BLOCKTIME=1
    export KMP_SETTINGS=1
    export KMP_AFFINITY=granularity=fine,compact,1,0
    # IOMP
    export LD_PRELOAD=${LD_PRELOAD}:${CONDA_PREFIX}/lib/libiomp5.so
    # Tcmalloc is a recommended malloc implementation that emphasizes fragmentation avoidance and scalable concurrency support.
    export LD_PRELOAD=${LD_PRELOAD}:${CONDA_PREFIX}/lib/libtcmalloc.so
}

function build_loadgen()
{
    # Build Loadgen
    if [ -d "./mlperf_inference" ]; then
        echo "The ./mlperf_inference already exists. Skipping clone operation"
    else 
        git clone --recurse-submodules https://github.com/mlcommons/inference.git mlperf_inference
    fi

    cd mlperf_inference/loadgen
    CFLAGS="-std=c++14 -O3" python setup.py bdist_wheel
    cd ..;
    pip install --force-reinstall loadgen/dist/`ls -r loadgen/dist/ | head -n1`
    cd -
    cp ../mlperf.conf ../../
    cd ../..
}


function download_cnndm()
{
    # Clone the repo
    if [ -d "./inference" ]; then
        echo "The ./inference directory already exists. Skipping clone operation."
    else
        # If the directory does not exist, clone the repository
        git clone https://github.com/mlcommons/inference.git
    fi
    cd inference
    cd language/gpt-j/

    # Download and process dataset 
    if [ -d "./data" ]; then 
        echo "Dataset already downloaded."
    else
        python3 download_cnndm.py
    fi
}

function prepare_calibration()
{
    python3 prepare-calibration.py                        \
             --calibration-list-file calibration-list.txt \
             --output-dir ./
}

function download_model()
{
    # Download model 
    if [ -f "./checkpoint.zip" ]; then
        echo "Model already exist. Skip downloading."
    else
        wget https://cloud.mlcommons.org/index.php/s/QAZ2oM94MkFtbQx/download --output-document checkpoint.zip
    fi 

    if [ -d "./model" ]; then
        echo "Model directory aldeady exist. Skip creating"
    else
        mkdir model
        cd ./model
        unzip ../checkpoint.zip
        cd ..
    fi
}

function run_benchmark()
{
    python3 main.py                                  \
        --scenario=Offline                           \
        --model-path=./model/gpt-j/checkpoint-final/ \
        --dataset-path=./data/cnn_eval.json          \
        --max_examples=${SAMPLE_SIZE}
}

function print_usage()
{
    echo -e "$(basename $0): Usage"
    echo "    $(basename $0) "
    echo "      -s <value> : [REQUIRED] number of samples to run"
}

        
if [ "$#" -eq "0" ];
then
    print_usage
    exit 1
fi          

                
while getopts 's:' opt; do
    case "$opt" in
       s)
           SAMPLE_SIZE=${OPTARG}
       ;;
       ?|h)
           print_usage
           exit 0
       ;;
    esac
done

if [ -z ${SAMPLE_SIZE} ];
then
    echo "Number of samples [-s] not specified"
    print_usage
    exit 1
fi


set_conda_environment
install_conda_packages
install_pip_packages
set_environment_variables
build_loadgen
download_cnndm
prepare_calibration
download_model
run_benchmark
unset_conda_environment
