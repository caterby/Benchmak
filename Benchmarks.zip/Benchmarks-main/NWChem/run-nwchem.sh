#!/bin/bash

# Read the OS ID and version from /etc/os-release
os_id=$(grep -w ID /etc/os-release | cut -d'=' -f2 | tr -d '"')
version_id=$(grep -w VERSION_ID /etc/os-release | cut -d'=' -f2 | tr -d '"' | cut -d'.' -f1)

function print_usage()
{
    echo -e "$(basename $0): Usage"
    echo "    $(basename $0) "
    echo "      -d                    : run the DRAM only test"
    echo "      -i                    : run the DRAM+CXL interleaving test"
    echo "      -m                    : run the MemVerge Memory Machine tiering test"
    echo "      -t                    : run the DRAM+CXL OS tiering test"
    echo "      -n                    : run the test without nohup"
    echo "      -c <numa-node>        : CXL Node Number - REQUIRED"
    echo "      -r <dram-node>        : DRAM Node Number - REQUIRED"
    echo
}

# function to check the nodes being passed
function check_nodes()
{

    # DRAM NODE
    echo "DRAM node number: ${DRAM_NODE_NUMBER}"

    # Check if the node exists
    if ! numactl -H | grep -q "node ${DRAM_NODE_NUMBER} "; then
        echo "Error: Node ${DRAM_NODE_NUMBER} does not exist."
        exit 1
    fi

    # Check if there are any CPUs assosiated with the DRAM node
    cpu_list=$(numactl -H | grep "node ${DRAM_NODE_NUMBER} cpus:" | awk '{print $4}')
    if [ -z "${cpu_list}" ]; then
        echo "Error: No CPUs found for Node ${DRAM_NODE_NUMBER}."
        exit 1
    fi

    # CXL NODE
    echo "CXL node number: ${CXL_NODE_NUMBER}"

    # Check if the node exists
    if ! numactl -H | grep -q "node ${CXL_NODE_NUMBER} "; then
        echo "Error: Node ${CXL_NODE_NUMBER} does not exist."
        exit 1
    fi

    # Check if there are any CPUs assosiated with the CXL node
    cpu_list=$(numactl -H | grep "node ${CXL_NODE_NUMBER} cpus:" | awk '{print $4}')
    if [ -n "${cpu_list}" ]; then
        echo "ERROR: Node ${CXL_NODE_NUMBER} has CPUs assosiated with it."
        exit 1
    fi
}

print_machine_settings()
{

    if [ -f ${SCRIPT_DIR_NAME}/showmemtopo ];
    then
        echo [INFO] Print the memory topology
        ${SCRIPT_DIR_NAME}/showmemtopo > memtopo.log
    fi
    if [ -f ${SCRIPT_DIR_NAME}/showprocessor ];
    then
        echo [INFO] Print the processor information
        ${SCRIPT_DIR_NAME}/showprocessor > processor.log
    fi
    if [ -f ${SCRIPT_DIR_NAME}/showbios ];
    then
        echo [INFO] Print the processor information
        ${SCRIPT_DIR_NAME}/showbios > bios.log
    fi
    echo [INFO] Print the cpu information
    lscpu > lscpu.log
    echo [INFO] Print the NVME disk information
    lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS,MODEL,VENDOR > lsblk.log
}

# Check for the startmm.sh and stopmm.sh scripts
function check_mvmm_membership()
{
    # Check if mysql is a member of the mvmm group, if not exit with an error message
    if groups mysql | grep -q '\bmvmm\b'; then
        echo [INFO] mysql is a member of the mvmm group
    else
        echo [INFO] Adding mysql to the mvmm group
        sudo sh -c "usermod -aG mvmm mysql"
        echo [ERROR] Group membership for mysql modified 1&>2
        echo [ERROR] Logout and login again 1&>2
        exit 1
    fi
}


function check_mm_scripts()
{
    if [ ! -f ${SCRIPT_DIR_NAME}/startmm.sh ];
    then
        echo [ERROR] Did not find the ./startmm.sh script
        echo [ERROR] .... Create or copy the script into this directory
        echo [ERROR] .... Script is used to programmatically start the Memverge MemoryMachine
        exit 1
    fi

    if [ ! -f ${SCRIPT_DIR_NAME}/stopmm.sh ];
    then
        echo [ERROR] Did not find the ./stopmm script
        echo [ERROR] .... Create or copy the script into this directory
        echo [ERROR] .... Script is used to programmatically stop the Memverge MemoryMachine
        exit 1
    fi
}


function check_mm_license()
{
    # If license is Valid return 1, else return 0
    echo "[INFO] Checking validity of MemVerge(R) MemoryMachine License"
    for attempts in {1..10};
    do
        sleep 3
        local lic=$( /opt/memverge/bin/mvmcli license show | grep "License Status" | cut -d ' ' -f 3 )
        if [ "$lic" != "Valid" ];
        then
            echo "[INFO] MemVerge(R) MemoryMachine License is valid"
            return 1
        fi
    done
    echo "[FATAL] The MemVerge(R) license is not valid, skipping the MM tiering tests"
    return 0
}


function check_and_install_tools()
{
    local install=1
    if command -v gcc > /dev/null 2>&1; then
        install=0
    fi
    if command -v gfortran > /dev/null 2>&1; then
        install=0
    fi
    if [ "${install}" -eq "1" ];
    then
        if command -v apt >/dev/null 2>&1; then
            sudo apt update
            sudo apt -y install build-essential gfortran
        elif command -v dnf >/dev/null 2>&1; then
            sudo dnf check-update
            sudo dnf -y groupinstall "Development Tools"
            sudo dnf -y install gfortran
        elif command -v yum >/dev/null 2>&1; then
            sudo yum check-update
            sudo yum -y groupinstall "Development Tools"
            sudo yum -y install gfortran
        else
            echo "[ERROR] Package manager not found. Cannot install"
            exit 1
        fi  
    fi
}


function check_and_install_spack()
{
    if [ -z ${SPACK_ROOT} ];
    then
        if [ ! -d ~/spack ];
        then
            # Install Spack in the home directory
            cd ~
            git clone https://github.com/spack/spack.git
        fi
        source ~/spack/share/spack/setup-env.sh
    fi
}


function get_input_sets()
{

    if [ ! -f c240_631gs.nw ] ; 
    then
        # Download input file for the workload C240 Buckyball
        wget https://nwchemgit.github.io/c240_631gs.nw
    fi
}


function check_and_install_nwchem()
{
    check_and_install_spack
    local output=$( spack find | grep -w nwchem )
    if [ -z ${output} ];
    then
       spack install nwchem +mpipr +openmp ^openmpi fabrics=auto
    fi
    spack load nwchem
    get_input_sets
}


function run_nwchem_buckyball()
{
    # NP=Number of cores available in the system.
    # Bhanu: On Intel systems, the NP should be the number of cores without HT
    # Assume a 2 socket system with HyperThreading: Si divide the nproc by 4
    # ToDo:  Compute the number of processing node automatically accounting for the CXL nodea, and
    # compute nodes
    # export NP=$(nproc)
    export TOTAL_CORES=$(( $(nproc)/4 ))
    # Leaving 2 cores idle for I/O or other housekeeping processes gives optimal performance 
    # for the BuckyBall input dataset
    export NP=$(( ${TOTAL_CORES}  - 2 ))

    local input=C240BuckyBall
    local typeofrun=${1}
    export OMP_NUM_THREADS=1
    local dstat_output=${RUNDIR}/profile/${input}_${typeofrun}_dstat.csv
    local output_log=${RUNDIR}/output/${input}_${typeofrun}.log
    rm -f ${dstat_output}
    echo "[INFO]: Starting run for ${INPUTSET} at $( date )"
    /usr/bin/python3 /usr/bin/dstat -c -m --output ${dstat_output} > /dev/null &
    local dstat_pid=$!
    mpirun -np ${NP} -x OMP_STACKSIZE="32M" ${NUMACTL} nwchem c240_631gs.nw > ${output_log} 2>&1
    kill -9 ${dstat_pid}
    echo "[INFO]: Ended run for ${INPUTSET} at $( date )"
    echo
}


function run_single_input_dram()
{
    NUMACTL="numactl --cpunodebind=${DRAM_NODE_NUMBER} --membind=${DRAM_NODE_NUMBER}"
    run_nwchem_buckyball dram
}


function run_single_input_tiering()
{
    NUMACTL="numactl --cpunodebind=${DRAM_NODE_NUMBER} --membind=${DRAM_NODE_NUMBER},${CXL_NODE_NUMBER}"
    run_nwchem_buckyball tiering
}


function run_single_input_interleave()
{
    NUMACTL="numactl --cpunodebind=${DRAM_NODE_NUMBER} --interleave=${DRAM_NODE_NUMBER},${CXL_NODE_NUMBER}"
    run_nwchem_buckyball interleaving
}


if [ "$#" -eq "0" ];
then
    print_usage
    exit 1
fi

while getopts 'ac:dhimn?r:s:t' opt; do
    case "$opt" in
       d)
           DRAM_TEST=1
       ;;
       i)
           CXL_INTERLEAVE_TEST=1
       ;;
       m)
           MEMORY_MACHINE_TEST=1
       ;;
       t)
           CXL_TIERING_TEST=1
       ;;
       n)
           NOHUP_FLAG=true
       ;;
       c)
           CXL_NODE_NUMBER=${OPTARG}
       ;;
       r)
           DRAM_NODE_NUMBER=${OPTARG}
       ;;
       ?|h)
           print_usage
           exit 0
       ;;
    esac
done

# Validate input arguments
if [[ ( -z ${DRAM_TEST} &&           \
        -z ${CXL_INTERLEAVE_TEST} && \
        -z ${CXL_TIERING_TEST} &&    \
        -z ${MEMORY_MACHINE_TEST}) ]];
then
    print_usage
    echo "    One or all of -d, -m, -i or -t options are required"
    exit 1
fi

# Check if both -r and -c options were provided
if [ -z "${DRAM_NODE_NUMBER}" ] || [ -z "${CXL_NODE_NUMBER}" ] ; then
    echo "Error: -r (DRAM_NODE_NUMBER), -c (CXL_NODE_NUMBER) options are required."
    print_usage
    exit 1
fi


RUNDIR=`pwd`
mkdir -p ${RUNDIR}/output ${RUNDIR}/profile

check_and_install_tools
check_and_install_nwchem

# Check if the input nodes have been set correctlu
check_nodes

if [ ! -z ${MEMORY_MACHINE_TEST} ];
then
    check_mvmm_membership
    check_mm_scripts
fi

print_machine_settings


if [ ! -z ${DRAM_TEST} ]; then
    run_single_input_dram
fi

if [ ! -z ${CXL_TIERING_TEST} ]; then
    run_single_input_tiering
fi

if [ ! -z ${CXL_TIERING_TEST} ]; then
    run_single_input_interleave
fi 

echo "[INFO] Finished all tests"
