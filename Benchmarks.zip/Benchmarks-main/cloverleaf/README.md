# cloverleaf
Setup and run scripts to run cloverleaf using spack manager
