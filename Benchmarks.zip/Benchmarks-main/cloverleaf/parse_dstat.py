#!/usr/bin/env  python3

import argparse
import pandas as pd
import sys

def process_dstat_results(filename):
    result = {}
    df = pd.read_csv(filename, skiprows=4, on_bad_lines='skip')
    # The columns are actually loaded in directly as the first data row, so set them in the dataframe
    df.columns = df.iloc[0]
    # Ignore the first data row, as it may be incomplete.  This is a known problem wiht dstat reported data
    data = df[2:]
    data = data.apply(pd.to_numeric)
    cpu_cols = ['total usage:usr', 'total usage:sys', 'total usage:idl', 'total usage:wai', 'total usage:stl']
    mem_cols = ['used', 'free', 'buf', 'cach']
    disk_cols = ['dsk/datadisk:read', 'dsk/datadisk:writ']
    io_cols = ['read', 'writ']

    if 'idl' in data.columns:
        result['CPU Util'] = (100.0 - data['idl'].mean()).round(2)
        result['CPU Wait'] = data['wai'].mean().round(2)
    else:
        result['CPU Util'] = (100.0 - data['total usage:idl'].mean()).round(2)
        result['CPU Wait'] = data['total usage:wai'].mean().round(2)

    result['Memory used (avg)'] = data['used'].mean().round(2)
    result['Memory used (max)'] = data['used'].max().round(2)
    result['Memory free'] = data['free'].max().round(2)
    result['Memory buf'] = data['buf'].max().round(2)
    result['Memory cach'] = data['cach'].max().round(2)
    if 'dsk_read' in data.columns:
        result['Disk Read (avg)'] = data['dsk_read'].mean().round(2)
        result['Disk Read (max)'] = data['dsk_read'].max().round(2)
        result['Disk Write (avg)'] = data['dsk_writ'].mean().round(2)
        result['Disk Write (max)'] = data['dsk_writ'].max().round(2)
        result['IOPS Read (avg)'] = data['iops_reads'].mean().round(2)
        result['IOPS Read (max)'] = data['iops_reads'].max().round(2)
        result['IOPS Write (avg)'] = data['iops_writ'].mean().round(2)
        result['IOPS Write (max)'] = data['iops_writ'].max().round(2)
    result['Input'] = filename.split('_')[1]
    result['size'] = int(filename.split('_')[1][2:])

    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('file', nargs='+', type=argparse.FileType('r'))
    args = parser.parse_args()

    # print(args.file)
    printheaders = False
    if (len(args.file) > 1):
        printheaders = True

    df = pd.DataFrame(
        columns=['Input', 'size', 'CPU Util', 'CPU Wait',
                 'Memory used (avg)', 'Memory free', 'Memory buf', 'Memory cach',
                 'Memory used (max)',
                 'Disk Read (avg)', 'Disk Read (max)', 'Disk Write (avg)', 'Disk Write (max)',
                 'IOPS Read (avg)', 'IOPS Read (max)', 'IOPS Write (avg)', 'IOPS Write (max)'])
    for f in args.file:
        print("Processing input file", f.name)
        df.loc[len(df)] = process_dstat_results(f.name)
    df = df.sort_values(by=['size'])
    df = df.drop(columns='size')
    df.to_csv("system_util.csv", index=False, header=True)


if __name__ == '__main__':
    main()