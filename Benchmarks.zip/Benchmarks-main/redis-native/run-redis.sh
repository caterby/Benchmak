#!/bin/bash

SCRIPT_DIR=$( dirname $( readlink -f $0 ))
REDIS_CONF_NAME=redis.conf
REDIS_START_PORT=6379

trap ctrl_c INT

function ctrl_c()
{
    echo "Trapped CTRL-C"
    #stop_benchmarks
    stop_servers
}


function display_usage()
{
    echo "Usage:  $0 "
    echo "    -s <int>    : Number of servers to spin up"
    echo "    -t <int>    : Time in seconds to test"
    echo "    -n <int>    : memory mode: 0 = DRAM, 1 = numa membind, 2 = numa interleaving, 3 = MM, 4 = CXL"
    echo "    -m <int>    : Size in GB for each server, minimum 32"
    echo "    -p <policy> : redis replacement policy allkeys-lru|allkeys-lfu"
    echo "                  |volatile-lru|volatile-lfu|volatile-ramdom|allkeys-random"
    exit 0
}

function create_conf_files()
{
    echo "[INFO]: Creating configuration files"
    if [ ! -f ${SCRIPT_DIR}/${REDIS_CONF_NAME} ]; then
        echo "[FATAL]: ${REDIS_CONF_NAME} is not persent in ${SCRIPT_DIR}"
        echo "         Create the config file and retry"
        echo "         Sample file may be present as /etc/redis/redif.conf"
        exit 1
    fi

    REDIS_PORT=${REDIS_START_PORT}

    for instance in $(seq 1 ${NUM_SERVERS});
    do
        local DEST_CONF=redis_${instance}.conf
        cp ${SCRIPT_DIR}/${REDIS_CONF_NAME} ${DEST_CONF}
        REDIS_PORT=$(($REDIS_PORT + 1))
        sed -i 's/'${REDIS_START_PORT}'/'${REDIS_PORT}'/'  ${DEST_CONF}
        sed -i 's/redis\.log/redis_'${instance}'.log/' ${DEST_CONF}
        # Open maxmemory config parameter that has been masked out
        sed -i 's/^# maxmemory-policy/maxmemory-policy/' ${DEST_CONF}
        sed -i 's/^# maxmemory /maxmemory /' ${DEST_CONF}
        sed -i 's/^maxmemory .*/maxmemory '${MEMSIZE}'gb/' ${DEST_CONF}
        sed -i 's/^maxmemory-policy .*/maxmemory-policy '${MEMPOLICY}'/' ${DEST_CONF}
        sed -i 's/^save/# save/g' ${DEST_CONF}
        sed -i 's/^# save ""/save ""/' ${DEST_CONF}
    done

    echo "[INFO]: Done creating conf files"
}


function start_servers()
{
    echo "[INFO]: Start redis server instances"

    REDIS_PORT=${REDIS_START_PORT}

    for instance in $(seq 1 ${NUM_SERVERS});
    do
        local DEST_CONF=redis_${instance}.conf
        REDIS_PORT=$(($REDIS_PORT + 1))
        ${NUMA_CMD} redis-server ./${DEST_CONF} &
        pids[${instance}]=$!
        if [ "$?" -ne "0" ]; then
            echo "[FATAL]: Instance ${instance} failed to start"
            stop_servers
        fi
    done
    echo "[INFO]: Wait 5 seconds for all the instances to spin up"
    sleep 5
    echo "[INFO]: Done starting server instances"
}

function stop_servers()
{
    echo "[INFO]: Stopping server instances"
    if [ ${#pids[@]} -eq 0 ]; then
        echo "[INFO]: No server has started, exiting"
        exit 0
    fi

    REDIS_PORT=${REDIS_START_PORT}
    for instance in $(seq 1 ${NUM_SERVERS});
    do
        REDIS_PORT=$(($REDIS_PORT + 1))
        redis-cli -p ${REDIS_PORT} SHUTDOWN
    done

    echo "[INFO]: Done stopping server instances"
}

function create_output_directories()
{
    echo "[INFO]: Create output directories"
    mkdir -p ${OUTPUT_PREFIX}/${NUM_SERVERS}
    echo "[INFO]: Done"
}

function remove_output_directories()
{
    echo "[INFO]: Remove output directories"
    rm -rf ${OUTPUT_PREFIX}/${NUM_SERVERS}
    echo "[INFO]: Done"
}

function warmup_database()
{
    echo "[INFO]: Start database warmup"
    REDIS_PORT=${REDIS_START_PORT}

    for instance in $(seq 1 ${NUM_SERVERS});
    do
        local DEST_CONF=redis_${instance}.conf
        REDIS_PORT=$(($REDIS_PORT + 1))
        numactl --cpunodebind 0 memtier_benchmark \
            --test-time=${TESTTIME} \
            --select-db=0 \
            -n allkeys \
            --key-maximum=30000000 \
            --data-size-range=1000-16383 \
            --key-pattern=G:G \
            --ratio=1:0 \
            --pipeline=4 \
            --random-data \
            --distinct-client-seed \
            --randomize \
            --port  ${REDIS_PORT} > ${OUTPUT_PREFIX}/${NUM_SERVERS}/warm_up_${instance}.log 2>&1 &

        warmpids[${instance}]=$!
        if [ "$?" -ne "0" ]; then
            echo "[FATAL]: Warmup of Instance ${instance} failed to start"
        fi
    done

    for pid in ${warmpids[*]}; do
        wait $pid
    done

    # Check if any of the servers has been killed or stopped
    REDIS_PORT=${REDIS_START_PORT}
    for instance in $(seq 1 ${NUM_SERVERS});
    do
        REDIS_PORT=$(($REDIS_PORT + 1))
        local DEST_PID=/data/redis/redis-server_${REDIS_PORT}.pid
        while read -r line; do
            ps -p $line > /dev/null
            if [ "$?" -ne "0" ]; then
                echo "[FATAL]: Server process ${pid} was killed; Stopping run"
                return 1
            fi
        done < ${DEST_PID}
    done

    echo "[INFO]: Done database warmup"
    return 0
}

function run_benchmark()
{
    echo "[INFO]: Start benchmark run"
    REDIS_PORT=${REDIS_START_PORT}

    for instance in $(seq 1 ${NUM_SERVERS});
    do
        local DEST_CONF=redis_${instance}.conf
        REDIS_PORT=$(($REDIS_PORT + 1))
        numactl --cpunodebind 0 memtier_benchmark \
            --test-time=${TESTTIME} \
            --select-db=0 \
            -n allkeys \
            --key-maximum=30000000 \
            --data-size-range=1000-16383 \
            --key-pattern=G:G \
            --ratio=1:10 \
            --wait-ratio=10:1 \
            --pipeline=4 \
            --random-data \
            --distinct-client-seed \
            --randomize \
            --port  ${REDIS_PORT} > ${OUTPUT_PREFIX}/${NUM_SERVERS}/bench_${instance}.log 2>&1 &

        if [ "$?" -ne "0" ]; then
            echo "[FATAL]: Benchmark run of Instance ${instance} failed to start"
        fi
        runpids[${instance}]=$!
    done

    for pid in ${runpids[*]}; do
        wait $pid
    done

    # Check if any of the servers has been killed or stopped
    REDIS_PORT=${REDIS_START_PORT}
    for instance in $(seq 1 ${NUM_SERVERS});
    do
        REDIS_PORT=$(($REDIS_PORT + 1))
        local DEST_PID=/data/redis/redis-server_${REDIS_PORT}.pid
        while read -r line; do
            ps -p $line > /dev/null
            if [ "$?" -ne "0" ]; then
                echo "[FATAL]: Server process ${pid} was killed; Stopping run"
                return 1
            fi
        done < ${DEST_PID}
    done
    echo "[INFO]: Done benchmark run"
    return 0
}



NUMA_POLICY=0

while getopts "?hs:t:n:m:p:" opt; do
    case $opt in
    n)
        NUMA_POLICY=${OPTARG}
        ;;
    s)
        NUM_SERVERS=${OPTARG}
        ;;
    t)
        TESTTIME=${OPTARG}
        ;;
    m)
        MEMSIZE=${OPTARG}
        ;;
    p)
        MEMPOLICY=${OPTARG}
        ;;
    ?|h)
        display_usage
        ;;
    esac
done

if [ -z "${NUM_SERVERS}" ] || [ "${NUM_SERVERS}" -le "0" ]; then
    echo "[ERROR]: Invalid number of servers"
    display_usage
fi

if [ -z "${MEMSIZE}" ] || [ "${MEMSIZE}" -lt "64" ]; then
    echo "[ERROR]: Invalid value for MEMSIZE, should be at least 64"
    display_usage
fi

case ${NUMA_POLICY} in
    0)
        NUMA_CMD="numactl --cpunodebind 1 --membind 1 "
        OUTPUT_PREFIX=dram
        ;;
    1)
        NUMA_CMD="numactl --cpunodebind 1 --membind 1,2 "
        OUTPUT_PREFIX=tier
        ;;
    2)
        NUMA_CMD="numactl --cpunodebind 1 --interleave 1,2 "
        OUTPUT_PREFIX=interleave
        ;;
    3)
        # Start the memory machine before running tests
        NUMA_CMD="numactl --cpunodebind 1 --membind 1 /opt/memverge/bin/mm "
        OUTPUT_PREFIX=mm
        ;;
    4)
        NUMA_CMD="numactl --cpunodebind 1 --membind 2 "
        OUTPUT_PREFIX=cxl
        ;;
esac

case ${MEMPOLICY} in
    "allkeys-lru"|"allkeys-lfu"|"volatile-lru"|"volatile-lfu"|"volatile-ramdom"|"allkeys-random")
        ;;
    *)
        echo "Memory Policy is incorrect"
        display_usage
        ;;
esac


invalid_run=0
create_conf_files
start_servers

create_output_directories
warmup_database
if [ "$?" -eq "0" ]; then
    run_benchmark
    if [ "$?" -ne 0 ]; then
        invalid_run=1
    fi
else
    invalid_run=1
fi

stop_servers
if [ "${invalid_run}" -eq "1" ] ; then 
    remove_output_directories
    exit 1
fi

exit 0
