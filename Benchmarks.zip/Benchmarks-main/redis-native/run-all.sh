#!/bin/bash

SCRIPT_DIR=$( dirname $( readlink -f $0 ))
# set -x

function display_usage()
{
    echo "Usage:  $0 -t [TIME TO TEST IN SECONDS]  -m [MEMORY SIZE]"
    echo "    -t <value> : Time in seconds to test"
    echo "    -m <value> : Size in GB for each server, minimum 32"
    exit 0
}

function run_benchmark()
{
    servers=1
    while true
    do
        echo "[INFO]: Start run with ${servers} instances"
        ${SCRIPT_DIR}/run-redis.sh -s ${servers} -t ${TESTTIME} -n $1 -p ${policy} -m ${MEMSIZE}
        if [ "$?" -ne "0" ]; then
            break
        fi
        echo "[INFO]: Sleep fo 30 seconds between runs to enable open ports to close"  
        sleep 30
        servers=$((${servers} + 1))
    done
}

function run-tests()
{
    echo "[INFO]: Start redis scaling tests"
    #for policy in "allkeys-lru"  "allkeys-lfu" "volatile-lru" "volatile-lfu" "volatile-random" "allkeys-random"
    for policy in "allkeys-lru"
    do
        echo "[INFO]: Running test for $policy"
        mkdir -p ${policy}
        cd  ${policy}

        echo "[INFO]:     Start dram scaling test"
        run_benchmark 0 > dram.log
        echo "[INFO]:     Finished dram scaling test"
        echo

        echo "[INFO]:     Start cxl scaling test"
        run_benchmark 4 > cxl.log
        echo "[INFO]:     Finished cxl scaling test"
        echo

        echo "[INFO]:     Start membind scaling test"
        run_benchmark 1 > tier.log
        echo "[INFO]:     Finished membind scaling test"
        echo

        echo "[INFO]:     Start MemoryMachine scaling test"
        sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"
        sleep 5
        sudo ~/Projects/tpcc_scripts/startmm.sh -d 1 -c 2
        if [ "$?" -eq "0" ]; then
            run_benchmark 3 > mm.log
            sudo ~/Projects/tpcc_scripts/stopmm.sh
        fi
        echo "[INFO]:     Finished  MemoryMachine scaling test"
        echo

        cd ..
    done
    echo "[INFO]: Done redis scaling tests"
}


while getopts "?hs:t:n:m:p:" opt; do
    case $opt in
    t)
        TESTTIME=${OPTARG}
        ;;
    m)
        MEMSIZE=${OPTARG}
        ;;
    ?|h)
        display_usage
        ;;
    esac
done

if [ -z "${TESTTIME}" ] || [ -z "${MEMSIZE}" ]; then
    echo "[ERROR]:  Invalid arguments"
    display_usage
fi

run-tests
set +x
