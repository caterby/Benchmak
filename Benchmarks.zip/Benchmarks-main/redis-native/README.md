# redis-native
Performance scripts to enable redis scaling tests upto the size of installed memory
