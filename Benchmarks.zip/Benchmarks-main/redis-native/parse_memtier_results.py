#!/usr/bin/env python3

import argparse
import pandas as pd
import sys
import re
import io


def process_memtier_results(filename):
    result = {}
    file = open(filename, 'r')
    Lines = file.readlines()

    for line in Lines:
        # print(line)
        line = line.strip(' ').strip('\n')
        if line.startswith('Totals '):
            line1 = re.sub(' +', ',', line)
            res_array = line1.split(',')
            result['ops/sec'] = float(res_array[1])
            result['hits/sec'] = float(res_array[2])
            result['miss/sec'] = float(res_array[3])
            result['avg_latency'] = float(res_array[5])
            result['p50_latency'] = float(res_array[6])
            result['p99_latency'] = float(res_array[7])
            result['kb/s'] = float(res_array[8])
    return result

def summarize_memtier_results(df):
    result = {}
    result['ops/sec'] = df['ops/sec'].sum()
    result['hits/sec'] = df['hits/sec'].sum()
    result['miss/sec'] = df['miss/sec'].sum()
    result['avg_latency'] = df['avg_latency'].mean()
    result['p50_latency'] = df['p50_latency'].mean()
    result['p99_latency'] = df['p99_latency'].mean()
    result['kb/s'] = df['kb/s'].sum()
    return result


def print_header():
    print("Ops/src", end=',')
    print("Hits/sec", end=',')
    print("Misses/sec", end=',')
    print("Avg. Latency", end=',')
    print("P50 Latency", end=',')
    print("P99 Latency", end=',')
    print("KB/sec", end=',')
    print()


def main():
    parser = argparse.ArgumentParser()      
    parser.add_argument('file', nargs='+', type=argparse.FileType('r'))
    args = parser.parse_args()

    # print(args.file)
    printheaders = False
    if (len(args.file) > 1):
        printheaders = True

    df = pd.DataFrame(columns=['ops/sec', 'hits/sec', 'miss/sec', 'avg_latency', 'p50_latency', 'p99_latency', "kb/s"])
    for f in args.file:
        df.loc[len(df)] = process_memtier_results(f.name)
    df.loc[len(df)] = summarize_memtier_results(df)
    df.to_csv("merged.csv", index=False, header=printheaders)


if __name__ == '__main__':
    main()