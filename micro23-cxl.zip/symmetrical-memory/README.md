# cxl\_type3\_tests
This is the respository that holds the artifacts of MICRO'23 -- Demystifying CXL Memory with True CXL-Ready Systems and CXL Memory Devices

Let us know if you have any questions via [email](mailto:yans3@illinois.edu)

Thank you! :)
