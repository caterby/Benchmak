#sudo cpupower --cpu all frequency-set --governor osndemand
sudo cpupower --cpu all frequency-set --governor ondemand

