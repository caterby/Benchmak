export CLOSEST_CORE=0
export CLOSEST_NODE=0
export NODE_MAX=2
export TSC_FREQ=2100

echo "closest node to CXL=${CLOSEST_NODE}"
echo "closest core to CXL=${CLOSEST_CORE}"
echo "TSC_FREQ: $TSC_FREQ (Mhz)"
