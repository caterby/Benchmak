sudo cpupower --cpu all frequency-info | grep "current CPU frequency"
